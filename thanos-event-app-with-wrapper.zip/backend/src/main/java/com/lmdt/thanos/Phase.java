package com.lmdt.thanos;

public enum Phase { PHASE1, PHASE2, FINISHED }
