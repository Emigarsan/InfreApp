package com.lmdt.thanos;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
class TableService {
  private final TableRepo tableRepo;
  private final PlayerRepo playerRepo;

  public List<TableEntity> list() { return tableRepo.findAll(); }

  @Transactional
  public TableEntity create(String name, Mode mode, List<PlayerEntity> players){
    TableEntity t = new TableEntity();
    t.setName(name);
    t.setMode(mode);
    t.setPlayerCount(players.size());
    tableRepo.save(t);
    for (PlayerEntity p : players){
      p.setTableId(t.getId());
      playerRepo.save(p);
    }
    return t;
  }
}

@Service
@RequiredArgsConstructor
class SessionService {
  private final SessionRepo sessionRepo;
  private final TableRepo tableRepo;
  private final SimpMessagingTemplate broker;

  @Value("${app.p1.normal}") private int p1NormalDefault;
  @Value("${app.p1.expert}") private int p1ExpertDefault;
  @Value("${app.p2.normal}") private int p2NormalDefault;
  @Value("${app.p2.expert}") private int p2ExpertDefault;

  private SessionEntity getOrCreate() {
    return sessionRepo.findTop1ByOrderByStartedAtDesc().orElseGet(() -> {
      SessionEntity s = new SessionEntity();
      s.setPhase(Phase.PHASE1);
      s.setLocked(true);
      s.setHpCurrent(0);
      s.setHpMax(0);
      s.setTotalPlayers(0);
      s.setP1NormalContrib(p1NormalDefault);
      s.setP1ExpertContrib(p1ExpertDefault);
      s.setP2NormalContrib(p2NormalDefault);
      s.setP2ExpertContrib(p2ExpertDefault);
      return sessionRepo.save(s);
    });
  }

  @Transactional
  public SessionEntity start(Integer p1N, Integer p1E, Integer p2N, Integer p2E){
    SessionEntity s = getOrCreate();
    s.setPhase(Phase.PHASE1);
    s.setLocked(false);
    s.setP1NormalContrib(p1N!=null?p1N:p1NormalDefault);
    s.setP1ExpertContrib(p1E!=null?p1E:p1ExpertDefault);
    s.setP2NormalContrib(p2N!=null?p2N:p2NormalDefault);
    s.setP2ExpertContrib(p2E!=null?p2E:p2ExpertDefault);

    var tables = tableRepo.findAll();
    int hpMax = tables.stream().mapToInt(t -> t.getMode()==Mode.NORMAL ? s.getP1NormalContrib() : s.getP1ExpertContrib()).sum();
    int totalPlayers = tables.stream().mapToInt(TableEntity::getPlayerCount).sum();
    s.setHpMax(hpMax);
    s.setHpCurrent(hpMax);
    s.setTotalPlayers(totalPlayers);
    sessionRepo.save(s);
    publish(s);
    return s;
  }

  @Transactional
  public SessionEntity adjust(int delta){
    SessionEntity latest = getOrCreate();
    // pessimistic lock by id
    SessionEntity s = sessionRepo.lockById(latest.getId()).orElse(latest);
    if (s.isLocked() || s.getPhase()==Phase.FINISHED) {
      publish(s);
      return s;
    }
    int next = s.getHpCurrent() + delta;
    if (next < 0) next = 0;
    s.setHpCurrent(next);

    if (next == 0){
      if (s.getPhase()==Phase.PHASE1){
        s.setLocked(true);
        sessionRepo.save(s);
        publish(s);
        advanceToPhase2Internal(s.getId());
      } else if (s.getPhase()==Phase.PHASE2){
        s.setLocked(true);
        s.setPhase(Phase.FINISHED);
        sessionRepo.save(s);
        publish(s);
      } else {
        sessionRepo.save(s);
        publish(s);
      }
    } else {
      sessionRepo.save(s);
      publish(s);
    }
    return s;
  }

  @Transactional
  public SessionEntity advanceToPhase2(){
    SessionEntity latest = getOrCreate();
    return advanceToPhase2Internal(latest.getId());
  }

  private SessionEntity advanceToPhase2Internal(UUID id){
    SessionEntity s = sessionRepo.lockById(id).orElseThrow();
    var tables = tableRepo.findAll();
    int hpMax = tables.stream().mapToInt(t -> t.getMode()==Mode.NORMAL ? s.getP2NormalContrib() : s.getP2ExpertContrib()).sum();
    s.setPhase(Phase.PHASE2);
    s.setHpMax(hpMax);
    s.setHpCurrent(hpMax);
    s.setLocked(false);
    sessionRepo.save(s);
    publish(s);
    return s;
  }

  private void publish(SessionEntity s){
    broker.convertAndSend("/topic/session", SessionDto.from(s));
  }
}
