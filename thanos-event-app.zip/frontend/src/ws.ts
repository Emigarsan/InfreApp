import SockJS from 'sockjs-client'
import { Client } from '@stomp/stompjs'

let client: Client | null = null;

export function connect(onMessage:(msg:any)=>void){
  client = new Client({
    webSocketFactory: () => new SockJS('/ws'),
    reconnectDelay: 2000,
    onConnect: () => {
      client?.subscribe('/topic/session', (frame) => {
        onMessage(JSON.parse(frame.body));
      });
    }
  });
  client.activate();
}

export function disconnect(){
  client?.deactivate();
}

export function isConnected(){ return !!client?.connected; }
