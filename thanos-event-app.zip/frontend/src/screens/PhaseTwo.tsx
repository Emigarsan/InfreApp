import { useEffect, useState } from 'react'
import { connect, disconnect } from '../ws'

type Session = {
  phase: 'PHASE1'|'PHASE2'|'FINISHED',
  hp_current: number,
  hp_max: number,
  locked: boolean,
  total_players: number
}

export default function PhaseTwo(){
  const [session, setSession] = useState<Session | null>(null)
  useEffect(()=>{ connect(setSession); return ()=>disconnect(); },[])

  if(!session) return <div>Cargando…</div>
  if(session.phase!=='PHASE2' && session.phase!=='FINISHED') return <div>Esperando…</div>

  const pct = Math.min(100, session.total_players) // placeholder simple
  return (
    <div style={{display:'grid', placeItems:'center', gap:16}}>
      <img src="/thanos_phase2.png" alt="Thanos Fase 2" style={{maxWidth:320}}/>
      <div style={{fontSize:28}}>{session.hp_current} / {session.hp_max}</div>

      <div style={{width:'100%', maxWidth:600}}>
        <div style={{marginBottom:6}}>Participantes totales: {session.total_players}</div>
        <div style={{height:24, background:'#222', borderRadius:8}}>
          <div style={{height:24, width: pct+'%', background:'#6cf', borderRadius:8}}/>
        </div>
      </div>

      {session.phase==='FINISHED' && <div style={{fontSize:22}}>¡Evento completado!</div>}
    </div>
  )
}
