package com.lmdt.thanos;

import jakarta.persistence.*;
import lombok.Data;
import java.time.Instant;
import java.util.UUID;

@Entity @Table(name="tables")
@Data
public class TableEntity {
  @Id @GeneratedValue
  private UUID id;
  private String name;
  @Enumerated(EnumType.STRING)
  private Mode mode; // NORMAL/EXPERT
  private int playerCount;
  private Instant createdAt = Instant.now();
}

@Entity @Table(name="players")
@Data
class PlayerEntity {
  @Id @GeneratedValue
  private UUID id;
  private UUID tableId;
  private String hero;
  private String aspect;
}

@Entity @Table(name="session_state")
@Data
class SessionEntity {
  @Id @GeneratedValue
  private UUID id;
  @Enumerated(EnumType.STRING)
  private Phase phase; // PHASE1/PHASE2/FINISHED
  private int hpCurrent;
  private int hpMax;
  private boolean locked;
  private int totalPlayers;

  private int p1NormalContrib;
  private int p1ExpertContrib;
  private int p2NormalContrib;
  private int p2ExpertContrib;

  private Instant startedAt = Instant.now();
}
