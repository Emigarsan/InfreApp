package com.lmdt.thanos;

public enum Mode { NORMAL, EXPERT }
